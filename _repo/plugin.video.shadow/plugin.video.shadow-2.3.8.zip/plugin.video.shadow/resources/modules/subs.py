
def get_links(tv_movie,original_title,name,season_n,episode_n,season,episode,show_original_year,id,check_one=False):
    global global_var,stop_all
    return []
    