import requests
import re,time
import xbmc
from ..scraper import Scraper
import resolveurl as urlresolver
from universalscrapers.common import clean_title,clean_search,random_agent
#from universalscrapers.modules import cfscrape
#import base 64
  
class iwannawatch(Scraper):
    domains = ['https://www.iwannawatch.is/']
    name = "iwannawatch"
    sources = []

    def __init__(self):
        self.base_link = 'http://www.iwannawatch.is'
         #self.scraper = cfscrape.create_scraper()


    def scrape_movie(self, title, year, imdb, debrid = False):
        try:
            search_id = clean_search(title.lower()) 
            # use 'clean_search' to get clean title 

            #(movie name keeping spaces removing excess characters)

            start_url = self.base_link + '/?s=' +search_id.replace(' ','+')
            # construct search url attributes using site url
            #print '::::::::::::: START URL '+start_url
            # print to log to confirm 
            
            headers={'User-Agent':random_agent()}
            html = requests.get(start_url,headers=headers,timeout=5).content 
            # print html
            
            match = re.compile('<h2 class="post-title"><a href="(.+?)" title="(.+?)">.+?</a></h2>',re.DOTALL).findall(html) # Regex info on results page
            for item_url, name , in match:
                #print 'item_url>>>>>>>>>>>>>> '+item_url                                                # use print statments to confirm grabs check log
                #print 'name>>>>>>>>>>>>>> '+name


                            
             # confirm year if available in results sometines in name grab/or regex elsewhere
                    
                if clean_title(search_id).lower() in clean_title(name).lower():     # confirm name use 'clean_title' this will remove all unwanted
                 # incuding spaces to get both in same format to match if correct

                        # print 'Send this URL> ' + item_url
                        #confirm in log correct url(s) sent to get_source
                        self.get_source(item_url)
                         # send url to next stage
            return self.sources
        except:
            pass
            return[]

            
    def get_source(self,item_url):
        try:
            headers={'User-Agent':random_agent()}
            OPEN = requests.get(item_url,headers=headers,timeout=5).content
            Endlinks = re.compile('class="url".+?href="(.+?)"',re.DOTALL).findall(OPEN)      # regex to links
            for link in Endlinks:
            	print link
                if '1080' in link:
                    label = '1080p'
                elif '720' in link:
                    label = '720p'
                elif 'HD' in link:
                    label = 'HD'
                else:
                    label = 'SD'
                
                host = link.split('//')[1].replace('www.','')
                host = host.split('/')[0].split('.')[0].title()
                self.sources.append({'source': host, 'quality': label, 'scraper': self.name, 'url': link,'direct': False}) #this line will depend what sent     
        except:
            pass
#iwannawatch().scrape_movie('wonder woman', '2017','')
# you will need to regex/split or rename to get host name if required from link unless available on page it self 
