script.module.chardet
=====================

chardet library module packed for Kodi

See https://github.com/chardet/chardet
